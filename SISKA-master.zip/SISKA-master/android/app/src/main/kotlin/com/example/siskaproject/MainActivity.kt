package com.example.siskaproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
