## REST API

API ini akan digunakan untuk mengolah data di Aplikasi SISKA.

Rest API ini menggunakan PHP berbasis Object dan MySQL sebagai Database nya, serta menggunakan JSON sebagai Output hasil nya.

* db.php (File config untuk terkoneksi dengan database)
* restapi.php (File yang menyimpan semua API)
