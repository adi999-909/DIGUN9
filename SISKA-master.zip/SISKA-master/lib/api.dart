class Api{
  static String login = "https://rkhalid.net/restapi.php?function=login_user";
}